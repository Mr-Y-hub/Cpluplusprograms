#include<iostream>
using namespace std;

int main(){
	
	int m,i;
	cout<<"enter m:";
			cin>>m;
			cout<<"enter i: ";
			cin>>i;
	cout<<"number of leaves is: "<<i*(m-1)+1;
}