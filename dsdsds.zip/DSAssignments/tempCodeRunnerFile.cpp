j=0;j<a1.size;j++)
		cout<<